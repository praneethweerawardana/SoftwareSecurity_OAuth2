package com.PraneethWeerawardana.OAuth2GroupAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuth2GroupAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAuth2GroupAssignmentApplication.class, args);
	}

}
